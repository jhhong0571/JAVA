package com.example.o2o;

import com.example.o2o.domain.Board;
import com.example.o2o.domain.Member;
import com.example.o2o.domain.Role;
import com.example.o2o.repo.BoardRepo;
import com.example.o2o.repo.MemberRepo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootTest
class BoardRepositoryTest {
    @Autowired
    private MemberRepo memberRepo;
    @Autowired
    private BoardRepo boardRepo;
    @Autowired
    private PasswordEncoder encoder;
    @Test
    public void testInsert(){
        /*Member member1 = new Member();
        member1.setId("22");
        member1.setPassword(encoder.encode("1234"));
        member1.setName("둘리");
        member1.setRole(Role.MEMBER);
        member1.setEnabled(true);
        memberRepo.save(member1);

        Member member2 = new Member();
        member2.setId("timecosmos");
        member2.setPassword(encoder.encode("1234"));
        member2.setName("도우너");
        member2.setRole(Role.ADMIN);
        member2.setEnabled(true);
        memberRepo.save(member2);

        for(int i = 1; i<=13; i++){
            Board board = new Board();
            board.setMember(member1);
            board.setTitle(member1.getName()+"가 등록한 게시글 "+i);
            board.setContent(member1.getName()+"가 등록한 게시글 "+i);
            boardRepo.save(board);
        }
*/
        Member member2 = memberRepo.findById("20193346").orElse(null);
        for(int i = 1; i<=3; i++){
            Board board = new Board();
            board.setMember(member2);
            board.setTitle(member2.getName()+"가 등록한 게시글 "+i);
            board.setContent(member2.getName()+"가 등록한 게시글 "+i);
            boardRepo.save(board);
        }
    }
    @Test
    public void testGetBoard(){
        Board board = boardRepo.findById(1L).orElse(null);

        System.out.println("[ "+board.getSeq()+"번 게시글 상세 정보 ]");
        System.out.println("제목\t : "+board.getTitle());
        System.out.println("작성자\t : "+board.getMember().getName());
        System.out.println("내용\t : "+board.getContent());
        System.out.println("등록일\t : "+board.getCreateDate());
        System.out.println("조회수\t : "+board.getCnt());
    }
    @Test
    public void testGetBoardList(){
        Member member = memberRepo.findById("22").orElse(null);

        System.out.println("[ "+member.getName()+"가 등록한 게시글 ]");
        for(Board board : member.getBoardList()){
            System.out.println("--->"+board.toString());
        }
    }
}
