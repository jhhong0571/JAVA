package com.example.o2o;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class O2OApplicationTests {

    @Test
    void contextLoads() {
    }

}
