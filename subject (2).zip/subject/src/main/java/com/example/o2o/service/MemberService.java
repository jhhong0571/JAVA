package com.example.o2o.service;

import com.example.o2o.domain.Member;
import com.example.o2o.entity.Information;
import com.example.o2o.entity.Lecture;
import com.example.o2o.entity.Rest;
import com.example.o2o.entity.memScore;
import com.example.o2o.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
public class MemberService {

    @Autowired
    private PasswordEncoder passwordEncoder;
    private final InformationRepo informationRepo;
    private final MemberRepo memberRepo;
    private final RestRepo restRepo;
    private final LectureRepo lectureRepo;
    private final ScoreRepo scoreRepo;

    @Autowired
    public MemberService(InformationRepo informationRepo, MemberRepo memberRepository, RestRepo restRepo, LectureRepo lectureRepo, ScoreRepo scoreRepo){
        this.informationRepo=informationRepo;
        this.memberRepo =memberRepository;
        this.restRepo=restRepo;
        this.lectureRepo=lectureRepo;
        this.scoreRepo=scoreRepo;
    }
    public Information getInformationById(String name){return informationRepo.findByIde(name);}
    public Member getMemberById(String name){return memberRepo.findById(name).orElse(null);}
    public Member pwchange(String id, String pw){
        Member mem = memberRepo.findById(id).orElse(null);
        assert mem != null;
        mem.setPassword(passwordEncoder.encode(pw));
        mem.setEnabled(true);
        return memberRepo.save(mem);
    }
    public Information infochange(String ide, String phone, String mail){
        Information inf = informationRepo.findByIde(ide);
        inf.setPhone(phone);
        inf.setMail(mail);
        return informationRepo.save(inf);
    }

    public List<Rest> getAllMemsRest(String name) {
        return restRepo.findAllByMemId(name);
    }

    public void createRest(Rest rest) {
        restRepo.save(rest);
    }

    public void createMember(Member mem) {
        memberRepo.save(mem);
    }

    public void createInformation(Information info) {
        informationRepo.save(info);
    }

    public void createLecture(Lecture lecture) { lectureRepo.save(lecture); }

    public void createScore(memScore sco) { scoreRepo.save(sco);}

    public void deleteRest(Long id) {
        restRepo.delete(restRepo.findById(id));
    }

    public List<Member> getAllMembers() {return memberRepo.findAll();}

    public void deleteMember(String id) {
        memberRepo.delete(memberRepo.findById(id).orElse(null));
    }

    public void deleteLecture(String id) {
        lectureRepo.delete(lectureRepo.findById(id).orElse(null));
    }

    public List<Rest> getAllRest() {return restRepo.findAll();}

    public void restChange(Long id) {
        Rest rest = restRepo.findById(id);
        assert rest != null;
        if(Objects.equals(rest.getAccept(), "Y")){
            rest.setAccept("N");
        }
        else{
            rest.setAccept("Y");
        }
        restRepo.save(rest);
    }

    public List<Lecture> getAllLectures() {return lectureRepo.findAll();}

    public Lecture getLectureById(String id) {return lectureRepo.findById(id).orElse(null);}

    public void updateLecture(String id, Lecture lecture) {
        lectureRepo.deleteById(id);
        createLecture(lecture);
    }

    public List<memScore> getAllScore() {return scoreRepo.findAll();}

    public void deleteScore(String id) {scoreRepo.delete(scoreRepo.findById(id).orElse(null));}

    public memScore getScoreById(Long id) {return scoreRepo.findById(id);}

    @Transactional
    public void updateScore(Long id, memScore sco) {
        scoreRepo.deleteById(id);
        createScore(sco);
    }

    public List<String> findmemlec(String name) {
        List<Lecture> lecture = lectureRepo.findAll();
        List<memScore> scores = scoreRepo.findAll();
        List<String> a = new ArrayList<>(Collections.emptyList());
        int k;
        int i=0;
        for(Lecture lec : lecture){
            k=0;
            for(memScore sco : scores){
                if(Objects.equals(sco.getLecture().getId(), lec.getId()) && Objects.equals(sco.getMember().getId(), name)){
                    k=1;
                    break;
                }
            }
            if(k==1)
                a.add("Y");
            else
                a.add("N");
            System.out.println(a.get(i));
            i++;
        }
        return a;
    }
    public void lectChange(String id, String name) {
        memScore score = scoreRepo.findByMemberAndLecture(memberRepo.findById(name).orElse(null), lectureRepo.findById(id).orElse(null));
        if(score==null){
            score=new memScore();
            score.setMember(memberRepo.findById(name).orElse(null));
            score.setLecture(lectureRepo.findById(id).orElse(null));
            score.setScore("-");
            scoreRepo.save(score);
        }
        else{
            scoreRepo.delete(score);
        }
    }

    public List<memScore> getAllScoreByLectId(String id) {
        List<memScore> scores = scoreRepo.findAll();
        List<memScore> sco = new ArrayList<>(Collections.emptyList());
        for(memScore scor : scores){
            if(Objects.equals(scor.getLecture().getId(), id)){
                sco.add(scor);
            }
        }
        return sco;
    }

    public List<memScore> getAllScoreByMemId(String name) {
        List<memScore> scores = scoreRepo.findAll();
        List<memScore> sco = new ArrayList<>(Collections.emptyList());
        for(memScore scor : scores){
            if(Objects.equals(scor.getMember().getId(), name)){
                sco.add(scor);
            }
        }
        return sco;
    }
}
