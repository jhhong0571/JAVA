package com.example.o2o.repo;

import com.example.o2o.domain.Member;
import com.example.o2o.entity.Lecture;
import com.example.o2o.entity.Rest;
import com.example.o2o.entity.memScore;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ScoreRepo extends JpaRepository<memScore, String> {
    public memScore findByMemberAndLecture(Member member, Lecture lecture);
    public void deleteById(Long id);
    public memScore findById(Long id);
}
