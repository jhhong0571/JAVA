package com.example.o2o.controller;

import com.example.o2o.domain.Board;
import com.example.o2o.domain.Member;
import com.example.o2o.entity.Information;
import com.example.o2o.entity.Lecture;
import com.example.o2o.entity.Rest;
import com.example.o2o.entity.memScore;
import com.example.o2o.service.BoardService;
import com.example.o2o.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
public class MemberController {
    private final MemberService memberService;
    private final BoardService boardService;
    @Autowired
    public MemberController(MemberService memberService, BoardService boardService){
        this.memberService=memberService;
        this.boardService=boardService;
    }

    @GetMapping("/info")
    public String info(Model model, Principal principal){
        Information info = memberService.getInformationById(principal.getName());
        //System.out.println(info.getId());
        model.addAttribute("info", info);
        return "/info";
    }
    @GetMapping("/info/edit")
    public String edit(Model model,Principal principal){
        Information info = memberService.getInformationById(principal.getName());
        model.addAttribute("info", info);
        return "/infoedit";
    }
    @PostMapping("/info/edit")
    public String edito(@ModelAttribute Information info, Principal principal){
        memberService.infochange(principal.getName(), info.getPhone(), info.getMail());
        return "redirect:/info";
    }
    @GetMapping("/info/pwedit")
    public String pwedit(Model model,Principal principal){
        Member mem = memberService.getMemberById(principal.getName());
        model.addAttribute("mem", mem);
        return "/pwedit";
    }
    @PostMapping("/info/pwedit")
    public String pwedito(@ModelAttribute Member member, Principal principal){
        memberService.pwchange(principal.getName(), member.getPassword());
        return "redirect:/info";
    }
    @GetMapping("/rest")
    public String rest(Model model, Principal principal){
        List<Rest> rest = memberService.getAllMemsRest(principal.getName());
        model.addAttribute("rest",rest);
        return "rest";
    }
    @GetMapping("/rest/add")
    public String restadd(Model model){
        model.addAttribute("rest",new Rest());
        return "restadd";
    }
    @PostMapping("/rest/add")
    public String restad(Rest rest,Principal principal){
        rest.setAccept("N");
        rest.setMemId(principal.getName());
        memberService.createRest(rest);
        return "redirect:/rest";
    }

    @GetMapping("/rest/delete/{id}")
    public String deleteUser(@PathVariable("id") Long Id) {
        memberService.deleteRest(Id);
        return "redirect:/rest";
    }

    @GetMapping("/lecture")
    public String lec(Model model, Principal principal){
        List<Lecture> lec = memberService.getAllLectures();
        List<String> Chk = memberService.findmemlec(principal.getName());
        model.addAttribute("lec",lec);
        model.addAttribute("Chk",Chk);
        model.addAttribute("id",principal.getName());
        return "/lectlist";
    }

    @GetMapping("/lecture/change/{id}")
    public String changelect(@PathVariable("id") String Id, Principal principal) {
        memberService.lectChange(Id, principal.getName());
        return "redirect:/lecture";
    }

    @GetMapping("/score")
    public String score(Model model, Principal principal){
        List<memScore> mem = memberService.getAllScoreByMemId(principal.getName());
        //System.out.println(info.getId());
        model.addAttribute("mem", mem);
        return "/score";
    }

    @GetMapping("/board")
    public String board(Model model, Principal principal){
        List<Board> brd = boardService.getAllBoard();
        model.addAttribute("brd", brd);
        model.addAttribute("mem",memberService.getMemberById(principal.getName()));
        return "/board";
    }

    @GetMapping("/board/delete/{id}")
    public String deleteboard(@PathVariable("id") Long Id) {
        boardService.deleteBoard(Id);
        return "redirect:/board";
    }

    @GetMapping("/board/read/{id}")
    public String readboard(@PathVariable("id") Long Id, Model model, Principal principal){
        Board brd = boardService.getBoardById(Id);
        model.addAttribute("brd", brd);
        model.addAttribute("mem",memberService.getMemberById(principal.getName()));
        return "/boarddetail";
    }

    @GetMapping("/board/add")
    public String boardadd(Model model){
        model.addAttribute("brd",new Board());
        return "boardadd";
    }

    @PostMapping("/board/add")
    public String boardad(Board brd,Principal principal){
        brd.setMember(memberService.getMemberById(principal.getName()));
        boardService.insertBoard(brd);
        return "redirect:/board";
    }

    @GetMapping("/board/edit/{id}")
    public String boardedit(@PathVariable("id") Long Id, Model model){
        model.addAttribute("brd",boardService.getBoardById(Id));
        return "boardedit";
    }

    @PostMapping("/board/edit/{id}")
    public String boarded(@PathVariable("id") Long Id, Board brd,Principal principal){
        brd.setMember(memberService.getMemberById(boardService.getBoardById(Id).getMember().getId()));
        boardService.deleteBoard(Id);
        boardService.insertBoard(brd);
        return "redirect:/board";
    }
}


