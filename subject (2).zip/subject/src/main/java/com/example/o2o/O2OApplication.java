package com.example.o2o;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class O2OApplication {

    public static void main(String[] args) {
        SpringApplication.run(O2OApplication.class, args);
    }

}
