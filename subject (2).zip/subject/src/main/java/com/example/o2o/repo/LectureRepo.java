package com.example.o2o.repo;

import com.example.o2o.entity.Lecture;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LectureRepo extends JpaRepository<Lecture, String> {

}
