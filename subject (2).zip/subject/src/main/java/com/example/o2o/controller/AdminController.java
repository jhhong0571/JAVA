package com.example.o2o.controller;

import com.example.o2o.domain.Board;
import com.example.o2o.domain.Member;
import com.example.o2o.domain.Role;
import com.example.o2o.entity.Information;
import com.example.o2o.entity.Lecture;
import com.example.o2o.entity.Rest;
import com.example.o2o.entity.memScore;
import com.example.o2o.service.BoardService;
import com.example.o2o.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final MemberService memberService;
    private final BoardService boardService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    public AdminController(MemberService memberService, BoardService boardService) {
        this.memberService = memberService;
        this.boardService = boardService;
    }

    @GetMapping("/mem")
    public String mem(Model model) {
        System.out.println("ㄸㅇ1");
        List<Member> mem = memberService.getAllMembers();
        System.out.println("ㄸㅇ2");
        model.addAttribute("mem", mem);
        System.out.println("ㄸㅇ3");
        return "/memlist";
    }

    @GetMapping("/mem/add")
    public String add(Model model) {
        model.addAttribute("info", new Information());
        return "memadd";
    }

    @PostMapping("/mem/add")
    public String ad(Information info) {
        info.setState("재학중");
        Member mem = new Member();
        mem.setId(info.getIde());
        mem.setPassword(passwordEncoder.encode("1234"));
        mem.setRole(Role.MEMBER);
        mem.setName(info.getName());
        mem.setEnabled(true);
        memberService.createMember(mem);
        memberService.createInformation(info);
        return "redirect:/admin/mem";
    }

    @GetMapping("/mem/delete/{id}")
    public String deleteMember(@PathVariable("id") String Id) {
        memberService.deleteMember(Id);
        return "redirect:/admin/mem";
    }

    @GetMapping("/rest")
    public String rest(Model model) {
        List<Rest> rest = memberService.getAllRest();
        model.addAttribute("rest", rest);
        return "adrest";
    }

    @GetMapping("/rest/change/{id}")
    public String changerest(@PathVariable("id") Long Id) {
        System.out.println("ㄸㅇ1");
        memberService.restChange(Id);
        System.out.println("ㄸㅇ2");
        return "redirect:/admin/rest";
    }

    @GetMapping("/lecture")
    public String lec(Model model) {
        List<Lecture> lec = memberService.getAllLectures();
        model.addAttribute("lec", lec);
        return "/leclist";
    }

    @GetMapping("/lecture/add")
    public String lecadd(Model model) {
        model.addAttribute("lect", new Lecture());
        return "lecadd";
    }

    @PostMapping("/lecture/add")
    public String lecad(Lecture lect) {
        System.out.println("ㄸㅇ1");
        memberService.createLecture(lect);
        System.out.println("ㄸㅇ2");
        return "redirect:/admin/lecture";
    }

    @GetMapping("/lecture/delete/{id}")
    public String deleteLecture(@PathVariable("id") String Id) {
        memberService.deleteLecture(Id);
        return "redirect:/admin/lecture";
    }

    @GetMapping("/lecture/edit/{id}")
    public String showEditUserForm(@PathVariable("id") String Id, Model model) {
        Lecture lecture = memberService.getLectureById(Id);
        model.addAttribute("lec", lecture);
        return "/lecedit";
    }

    @PostMapping("/lecture/edit/{id}")
    public String editUser(@PathVariable("id") String Id, @ModelAttribute Lecture lecture) {
        memberService.updateLecture(Id, lecture);
        return "redirect:/admin/lecture";
    }

    @GetMapping("/score")
    public String sco(Model model) {
        List<Lecture> lec = memberService.getAllLectures();
        model.addAttribute("lec", lec);
        return "/scolist";
    }

    @GetMapping("/score/edit/{id}")
    public String editScore(@PathVariable("id") String Id, Model model) {
        List<memScore> score = memberService.getAllScoreByLectId(Id);
        model.addAttribute("sco", score);
        model.addAttribute("lec", memberService.getLectureById(Id));
        return "scoedit";
    }
    @GetMapping("/score/edito/{id}")
    public String editoScore(@PathVariable("id") Long Id, Model model) {
        memScore score = memberService.getScoreById(Id);
        model.addAttribute("sco", score);
        return "scoedito";
    }

    @PostMapping("/score/edito/{id}")
    public String editScore(@ModelAttribute memScore sco) {
        sco.setLecture(memberService.getScoreById(sco.getId()).getLecture());
        sco.setMember(memberService.getScoreById(sco.getId()).getMember());
        memberService.updateScore(sco.getId(),sco);
        return "redirect:/admin/score";
    }

    @GetMapping("/board")
    public String board(Model model, Principal principal){
        List<Board> brd = boardService.getAllBoard();
        model.addAttribute("brd", brd);
        model.addAttribute("mem",memberService.getMemberById(principal.getName()));
        return "/board";
    }

    @GetMapping("/board/delete/{id}")
    public String deleteboard(@PathVariable("id") Long Id) {
        boardService.deleteBoard(Id);
        return "redirect:/admin/board";
    }

    @GetMapping("/board/read/{id}")
    public String readboard(@PathVariable("id") Long Id, Model model, Principal principal){
        Board brd = boardService.getBoardById(Id);
        model.addAttribute("brd", brd);
        model.addAttribute("mem",memberService.getMemberById(principal.getName()));
        return "/boarddetail";
    }

    @GetMapping("/board/add")
    public String boardadd(Model model){
        model.addAttribute("brd",new Board());
        return "boardadd";
    }

    @PostMapping("/board/add")
    public String boardad(Board brd,Principal principal){
        brd.setMember(memberService.getMemberById(principal.getName()));
        boardService.insertBoard(brd);
        return "redirect:/admin/board";
    }

    @GetMapping("/board/edit/{id}")
    public String boardedit(@PathVariable("id") Long Id, Model model){
        model.addAttribute("brd",boardService.getBoardById(Id));
        return "boardedit";
    }

    @PostMapping("/board/edit/{id}")
    public String boarded(@PathVariable("id") Long Id, Board brd){
        brd.setMember(memberService.getMemberById(boardService.getBoardById(Id).getMember().getId()));
        boardService.deleteBoard(Id);
        boardService.insertBoard(brd);
        return "redirect:/admin/board";
    }
}