package com.example.o2o.repo;

import com.example.o2o.domain.Member;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberRepo extends JpaRepository<Member, String> {

}
