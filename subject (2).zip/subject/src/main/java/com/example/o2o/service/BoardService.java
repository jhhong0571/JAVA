package com.example.o2o.service;

import com.example.o2o.domain.Board;
import com.example.o2o.entity.Lecture;
import com.example.o2o.entity.memScore;
import com.example.o2o.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BoardService {
    private final MemberRepo memberRepo;
    private final BoardRepo boardRepo;

    @Autowired
    public BoardService(MemberRepo memberRepository, BoardRepo boardRepo){
        this.memberRepo=memberRepository;
        this.boardRepo=boardRepo;
    }
    public void insertBoard(Board board){
        boardRepo.save(board);
    }
    public void deleteBoard(Long seq){
        boardRepo.deleteById(seq);
    }

    public List<Board> getAllBoard() {return boardRepo.findAll();}

    public Board getBoardById(Long id) {return boardRepo.findById(id).orElse(null);}
}
