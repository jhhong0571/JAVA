package com.example.o2o.repo;

import com.example.o2o.domain.Board;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

public interface BoardRepo extends JpaRepository<Board, Long>,
        QuerydslPredicateExecutor<Board> {
}

