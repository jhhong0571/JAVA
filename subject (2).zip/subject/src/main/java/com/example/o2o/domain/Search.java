package com.example.o2o.domain;

public class Search {
}
